RegisterNetEvent('seatbelt:server:PlaySound', function(action, passengers)
    local decoded = {}

    if passengers and type(passengers) == "string" then
        local ok, data = pcall(json.decode, passengers)
        if ok and type(data) == "table" then
            decoded = data
        end
    elseif type(passengers) == "table" then
        decoded = passengers
    end

    if not Config.playSoundForPassengers then return end

    for _, ped in ipairs(decoded) do
        local volume = (ped == source) and Config.volume or Config.passengerVolume
        TriggerClientEvent("seatbelt:client:PlaySound", ped, action, volume)
    end
end)
