fx_version 'cerulean'
lua54 'yes'
game 'gta5'

author 'R.Robertson - Echo Kilo Studios'
description 'Seatbelt script with ox_lib, sounds, indicator, and ejection logic'

ui_page "client/html/index.html"

shared_script 'config.lua' 

files {
    'client/html/index.html',
    'client/html/buckle.ogg',
    'client/html/unbuckle.ogg',
    'client/html/chime.ogg'
}

client_scripts {
    '@ox_lib/init.lua',
    'config.lua',
    'client/main.lua'
}

server_scripts {
    'server/main.lua'
}
