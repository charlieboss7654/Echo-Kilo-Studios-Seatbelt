Config = {}

Config.enableEjection = false
Config.ejectVelocity = 60.0
Config.unknownEjectVelocity = 80.0
Config.unknownModifier = 17.0
Config.minDamage = 50.0

Config.fixedWhileBuckled = true

Config.playSound = true
Config.playSoundForPassengers = true
Config.volume = 0.6

Config.showUnbuckledIndicator = true
