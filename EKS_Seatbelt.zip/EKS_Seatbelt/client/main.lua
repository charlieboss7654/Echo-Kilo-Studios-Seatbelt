local seatbeltOn = false
local ped = PlayerPedId()
local uiactive = false

local chimePlaying = false
local chimePending = false
local chimeStartTime = 0

local exemptClasses = {
    [8] = true,
    [13] = true,
    [14] = true
}

CreateThread(function()
    while true do
        ped = PlayerPedId()
        Wait(500)
    end
end)

CreateThread(function()
    while true do
        Wait(10)
        if IsPedInAnyVehicle(ped, false) then
            local veh = GetVehiclePedIsIn(ped, false)
            local class = GetVehicleClass(veh)
            local engineOn = GetIsVehicleEngineRunning(veh)

            if not exemptClasses[class] then
                if seatbeltOn then
                    if Config.fixedWhileBuckled then
                        DisableControlAction(0, 75, true)
                        DisableControlAction(27, 75, true)
                    end
                    toggleUI(false)
                    stopChimeLoop()
                else
                    toggleUI(true)

                    if engineOn then
                        startChimeLoop()   
                    else
                        stopChimeLoop()
                    end

                    handleEjection(veh)
                end
            else
                seatbeltOn = false
                toggleUI(false)
                stopChimeLoop()
            end
        else
            if seatbeltOn then
                seatbeltOn = false
                toggleSeatbelt(false, false)
            end
            toggleUI(false)
            stopChimeLoop()
            Wait(1000)
        end
    end
end)

CreateThread(function()
    while true do
        Wait(100)

        if IsPedInAnyVehicle(ped, false) then
            local veh = GetVehiclePedIsIn(ped, false)
            local engineOn = veh ~= 0 and GetIsVehicleEngineRunning(veh) or false

            if chimePending then
                if seatbeltOn or not engineOn then
                    chimePending = false
                else
                    if GetGameTimer() - chimeStartTime >= 4000 then
                        chimePending = false
                        chimePlaying = true
                        SendNUIMessage({
                            type = "playChime",
                            volume = Config.volume or 0.6
                        })
                    end
                end
            end

            if chimePlaying and (seatbeltOn or not engineOn) then
                stopChimeLoop()
            end
        else
            if chimePlaying or chimePending then
                stopChimeLoop()
            end
        end
    end
end)

CreateThread(function()
    local lastPress = 0
    while true do
        Wait(0)
        if IsPedInAnyVehicle(ped, false) then
            if IsControlJustReleased(0, 23) then
                local now = GetGameTimer()
                if now - lastPress < 400 then
                    if seatbeltOn then
                        toggleSeatbelt(true, false)
                    end
                    lastPress = 0
                else
                    lastPress = now
                end
            end
        else
            lastPress = 0
            Wait(200)
        end
    end
end)

function toggleSeatbelt(playNotify, force)
    if force ~= nil then
        if force then
            playSound("buckle")
            seatbeltOn = true
            stopChimeLoop()
            SetFlyThroughWindscreenParams(10000.0, 10000.0, 17.0, 500.0)
            notify("Seatbelt fastened", "success")
        else
            playSound("unbuckle")
            seatbeltOn = false
            startChimeLoop()
            if Config.enableEjection then
                SetFlyThroughWindscreenParams(
                    Config.ejectVelocity,
                    Config.unknownEjectVelocity,
                    Config.unknownModifier,
                    Config.minDamage
                )
            end
            notify("Seatbelt removed", "error")
        end
        return
    end

    seatbeltOn = not seatbeltOn
    if seatbeltOn then
        playSound("buckle")
        stopChimeLoop()
        SetFlyThroughWindscreenParams(10000.0, 10000.0, 17.0, 500.0)
        notify("Seatbelt fastened", "success")
    else
        playSound("unbuckle")
        startChimeLoop()
        if Config.enableEjection then
            SetFlyThroughWindscreenParams(
                Config.ejectVelocity,
                Config.unknownEjectVelocity,
                Config.unknownModifier,
                Config.minDamage
            )
        end
        notify("Seatbelt removed", "error")
    end
end

function handleEjection(vehicle)
    if not Config.enableEjection then return end
    if seatbeltOn then return end

    local speed = GetEntitySpeed(vehicle) * 3.6
    local hasHit = HasEntityCollidedWithAnything(vehicle)

    if speed >= Config.ejectVelocity and hasHit then
        local coords = GetEntityCoords(ped)
        local fw = GetEntityForwardVector(vehicle)
        TaskLeaveVehicle(ped, vehicle, 16)
        Wait(100)
        SetEntityCoords(ped, coords.x + fw.x, coords.y + fw.y, coords.z)
        SetPedToRagdoll(ped, 1000, 1000, 0, false, false, false)
    end
end

function playSound(soundType)
    if not Config.playSound then return end

    if Config.playSoundForPassengers then
        local veh = GetVehiclePedIsUsing(ped)
        if not veh or veh == 0 then return end

        local maxSeats = GetVehicleMaxNumberOfPassengers(veh)
        local targets = {}

        for i = -1, maxSeats do
            if not IsVehicleSeatFree(veh, i) then
                local p = GetPedInVehicleSeat(veh, i)
                if p and p > 0 then
                    local id = NetworkGetPlayerIndexFromPed(p)
                    if id then
                        table.insert(targets, GetPlayerServerId(id))
                    end
                end
            end
        end

        TriggerServerEvent("seatbelt:server:PlaySound", soundType, json.encode(targets))
    else
        SendNUIMessage({ type = soundType, volume = Config.volume or 0.6 })
    end
end

function toggleUI(active)
    if not Config.showUnbuckledIndicator then return end
    if uiactive ~= active then
        uiactive = active
        SendNUIMessage({ type = active and "showindicator" or "hideindicator" })
    end
end

function startChimeLoop()
    if seatbeltOn or not IsPedInAnyVehicle(ped, false) then return end

    local veh = GetVehiclePedIsIn(ped, false)
    if not veh or veh == 0 then return end
    if not GetIsVehicleEngineRunning(veh) then return end

    if chimePlaying or chimePending then return end

    chimePending = true
    chimeStartTime = GetGameTimer()  
end

function stopChimeLoop()
    if chimePlaying or chimePending then
        SendNUIMessage({ type = "stopChime" })
        chimePlaying = false
        chimePending = false
        chimeStartTime = 0
    end
end

function notify(msg, type)
    if lib and lib.notify then
        lib.notify({
            title = "Seatbelt",
            description = msg,
            type = type,
            icon = type == "success" and "check" or "x"
        })
    else
        print(msg)
    end
end

RegisterCommand("toggleseatbelt", function()
    if IsPedInAnyVehicle(ped, false) then
        local veh = GetVehiclePedIsIn(ped)
        if not exemptClasses[GetVehicleClass(veh)] then
            toggleSeatbelt(true)
        end
    end
end, false)

RegisterKeyMapping("toggleseatbelt", "Toggle Seatbelt", "keyboard", "B")

RegisterNetEvent("seatbelt:client:PlaySound", function(action, volume)
    SendNUIMessage({ type = action, volume = volume or Config.volume or 0.6 })
end)

exports("status", function()
    return seatbeltOn
end)
